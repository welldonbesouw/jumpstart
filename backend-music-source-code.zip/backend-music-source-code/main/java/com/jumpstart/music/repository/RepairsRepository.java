package com.jumpstart.music.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jumpstart.music.models.Repairs;

public interface RepairsRepository extends JpaRepository<Repairs, Long> {

}
